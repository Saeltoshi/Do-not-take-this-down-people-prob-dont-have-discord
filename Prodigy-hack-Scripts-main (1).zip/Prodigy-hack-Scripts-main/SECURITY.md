# Security Policy

## Supported Versions

this verison of PHEx is 2.1.9
| Version | Supported          |
| ------- | ------------------ |
| 2.1.9   | :white_check_mark: |
|         |                    |
|         |                    |
|         |                    |

## Reporting a Vulnerability
There will be no updates as this hack is discountiued.
if there is issues please send it in the "Issues Section" ill make sure to send it to the creator instantly.
