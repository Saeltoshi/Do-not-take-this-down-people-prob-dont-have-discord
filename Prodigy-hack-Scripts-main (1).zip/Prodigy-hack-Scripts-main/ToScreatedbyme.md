# Prodigy-hack-Scripts
Credits to afkvido, heres their profile, https://github.com/ProdigyPNP/ProdigyMathGameHacking/commits?author=afkvido


Please do not use this daily, it could get you banned if so, prob use it 1-3 times a per 2 days.
Please also understand by using these hacks you are willing to use it for fun and not ruining the experince of other players by hacking to win the battle.


Tutorial on how to do get PHEx working if it isnt working!
1: Download the "Extenison" file
2: Depending what browser your using, type in edge://extensions or chrome://extensions
Also make sure the grammar is correct, i am sure i spelt it wrong.
3: Unload the file and select "Extension" file.
4: It should put PHEx in and it should work, have a good time using the hacks!




Side note: some hacks in PHEx can damage your account and make it inacessible. i seen it happen to alot of people.


Different version of Tutorial.
How to get hacks



1. Go to https://github.com/ProdigyPNP/ProdigyMathGameHacking/blob/master/PHEx/build/extension.zip

2. Click Download

3. Go to chrome://extensions

4. In the top right, enable Developer Mode

5. Drag and drop the downloaded zip file from step 1 into chrome://extensions.

6. Go to Prodigy

7. Log in as usual. When you enter a world, wait 5-20 seconds for a dropdown arrow to appear in the top left corner of your screen.
  
  
  SUMMARY OF DISCORD TOS!!
  Discord’s current ToS, which was last modified on October 19, gives users 90 days to opt out of the arbitration clause and the ToS goes into effect on November 2, 2018. The ToS now states: “If you're signing up for a new account, purchasing a game, downloading a game, or subscribing to Nitro, these Terms apply to you.
  
  
  
  SUMMARY OF HACK TOS!!
  This hack is used to help prodigy fix the hacks that they blantly ignored. So it should be used for fun.
