For the verison of SCHOOL PHEx here is a link to it or if you wanna download by all means go ahead, please read ToSicreated.md for TOS

Happy Hacking!
